package com.alain.taxiracedetector;
import android.content.Context;
public class DetectorStore {
    public static void save(Context c, String s) {
        c.getSharedPreferences("detector", Context.MODE_PRIVATE).edit().putString("last", s).apply();
    }
}
