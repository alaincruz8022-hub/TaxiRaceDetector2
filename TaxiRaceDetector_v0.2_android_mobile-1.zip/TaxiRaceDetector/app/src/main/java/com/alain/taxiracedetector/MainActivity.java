package com.alain.taxiracedetector;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.widget.*;

public class MainActivity extends Activity {
    EditText usdCup, eurUsd;
    TextView status, result;
    final Handler handler = new Handler();
    final Runnable refresher = new Runnable() {
        @Override public void run() {
            String last = getSharedPreferences("detector", MODE_PRIVATE).getString("last", "");
            result.setText(last.isEmpty() ? "Esperando mensajes de WhatsApp Business…" : last);
            handler.postDelayed(this, 1000);
        }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        status = findViewById(R.id.status);
        result = findViewById(R.id.result);
        usdCup = findViewById(R.id.usdCup);
        eurUsd = findViewById(R.id.eurUsd);

        findViewById(R.id.openSettings).setOnClickListener(v ->
            startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")));

        findViewById(R.id.save).setOnClickListener(v -> {
            try {
                getSharedPreferences("detector", MODE_PRIVATE).edit()
                    .putFloat("usdCup", Float.parseFloat(usdCup.getText().toString().trim()))
                    .putFloat("eurUsd", Float.parseFloat(eurUsd.getText().toString().trim()))
                    .apply();
                Toast.makeText(this, "Reglas guardadas", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Revisa los tipos de cambio", Toast.LENGTH_SHORT).show();
            }
        });

        float u = getSharedPreferences("detector", MODE_PRIVATE).getFloat("usdCup", 700f);
        float e = getSharedPreferences("detector", MODE_PRIVATE).getFloat("eurUsd", 1.17f);
        usdCup.setText(String.valueOf(u));
        eurUsd.setText(String.valueOf(e));
        status.setText("🟡 MODO PRUEBA: solo detecta, NO responde YO");
    }

    @Override protected void onResume() {
        super.onResume();
        handler.post(refresher);
    }

    @Override protected void onPause() {
        super.onPause();
        handler.removeCallbacks(refresher);
    }
}
