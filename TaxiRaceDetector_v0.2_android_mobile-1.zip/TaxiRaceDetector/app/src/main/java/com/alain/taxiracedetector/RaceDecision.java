package com.alain.taxiracedetector;
public class RaceDecision {
    public final boolean valid; public final String reason; public final String detail;
    public RaceDecision(boolean v, String r, String d) { valid=v; reason=r; detail=d; }
    public String toDisplay() {
        return (valid ? "🟢 CARRERA VÁLIDA\n" : "🔴 DESCARTADA\n") +
               detail + (valid ? "" : "\nMotivo: " + reason);
    }
}
