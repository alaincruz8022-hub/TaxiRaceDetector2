package com.alain.taxiracedetector;

import android.app.Notification;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import java.text.Normalizer;
import java.util.Locale;
import java.util.regex.*;

public class WhatsAppNotificationListener extends NotificationListenerService {
    private static final String WAB = "com.whatsapp.w4b";

    @Override public void onNotificationPosted(StatusBarNotification sbn) {
        if (!WAB.equals(sbn.getPackageName())) return;

        Notification n = sbn.getNotification();
        Bundle e = n.extras;
        String title = safe(e.getCharSequence(Notification.EXTRA_TITLE));
        String text = safe(e.getCharSequence(Notification.EXTRA_TEXT));
        String big = safe(e.getCharSequence(Notification.EXTRA_BIG_TEXT));
        String lines = safe(e.getCharSequenceArray(Notification.EXTRA_TEXT_LINES));

        String message = (big + "\n" + text + "\n" + lines).trim();
        if (message.isEmpty()) return;

        // Ignore obvious non-message/system notifications.
        String norm = norm(message);
        if (norm.contains("llamada") || norm.contains("videollamada")) return;

        RaceDecision d = RaceParser.evaluate(title, message, this);
        DetectorStore.save(this, d.toDisplay());
    }

    private static String safe(CharSequence s) { return s == null ? "" : s.toString(); }
    private static String safe(CharSequence[] a) {
        if (a == null) return "";
        StringBuilder b = new StringBuilder();
        for (CharSequence s : a) b.append(safe(s)).append("\n");
        return b.toString();
    }
    private static String norm(String s) {
        return Normalizer.normalize(s.toLowerCase(Locale.ROOT), Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "");
    }
}
