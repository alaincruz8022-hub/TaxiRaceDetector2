package com.alain.taxiracedetector;

import android.content.Context;
import java.text.Normalizer;
import java.time.LocalTime;
import java.util.*;
import java.util.regex.*;

public class RaceParser {
    static String norm(String s) {
        return Normalizer.normalize(s.toLowerCase(Locale.ROOT), Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "");
    }

    static RaceDecision evaluate(String title, String msg, Context c) {
        String x = norm(title + "\n" + msg);

        boolean airport = x.matches("(?s).*\\b(aeropuerto|aereopuerto|airport|hav|jose marti|varadero).* ".trim());
        if (!airport) return new RaceDecision(false, "No es aeropuerto", "Aeropuerto: ❌");

        Matcher pm = Pattern.compile("(?i)(?:pax|pasajeros?|pasaje/carga|personas?)\\s*[:=]?\\s*(\\d+)").matcher(x);
        int pax = pm.find() ? Integer.parseInt(pm.group(1)) : -1;
        if (pax < 1 || pax > 4) return new RaceDecision(false, "Pasajeros fuera de 1–4 o no identificados",
                "Pasajeros: " + (pax < 0 ? "?" : pax) + " ❌");

        boolean badComfort = x.matches("(?s).*(auto confort|carro confort|confort|aire acondicionado|climatizado|climatizada|con aire|\\ba/c\\b|\\bac\\b).*");
        if (badComfort) return new RaceDecision(false, "Solicita confort/aire", "Confort/aire: ❌");

        int bags = -1;
        Matcher combo = Pattern.compile("(?i)(\\d+)\\s*maletas?.*?(\\d+)\\s*carry\\s*-?on").matcher(x);
        if (combo.find()) {
            bags = Integer.parseInt(combo.group(1)) + Integer.parseInt(combo.group(2));
        } else {
            Matcher lm = Pattern.compile("(?i)(\\d+)\\s*(?:maletas?|equipajes?|bultos?)").matcher(x);
            if (lm.find()) bags = Integer.parseInt(lm.group(1));
        }
        if (bags < 0) return new RaceDecision(false, "Equipaje no identificado",
                "Equipaje: ? ⚠️ revisión necesaria");
        if (bags > 2) return new RaceDecision(false, "Más de 2 maletas/equipaje",
                "Equipaje: " + bags + " ❌");

        TimeResult tr = parseTime(x);
        if (!tr.known) return new RaceDecision(false, "Hora no identificada", "Hora: ? ❌");
        if (tr.hour < 7 || tr.hour >= 19) return new RaceDecision(false, "Fuera de 07:00–19:00",
                String.format(Locale.US, "Hora: %02d:%02d ❌", tr.hour, tr.minute));

        Price p = parsePrice(x, c);
        if (!p.known) return new RaceDecision(false, "Precio no identificado", "Precio: ? ❌");
        if (p.usd <= 20.0) return new RaceDecision(false, "Precio no supera 20 USD",
                String.format(Locale.US, "Precio: %.2f USD ❌", p.usd));

        return new RaceDecision(true, "", String.format(Locale.US,
                "Aeropuerto: ✅\nPasajeros: %d ✅\nEquipaje: %d ✅\nHora: %02d:%02d ✅\nPrecio: %.2f USD ✅\nConfort/aire: ❌ no solicitado",
                pax, bags, tr.hour, tr.minute, p.usd));
    }

    static TimeResult parseTime(String x) {
        if (x.contains("ahora")) {
            LocalTime t = LocalTime.now();
            return new TimeResult(true, t.getHour(), t.getMinute());
        }
        Matcher m = Pattern.compile("(?i)(\\d{1,2})(?::(\\d{2}))?\\s*(am|pm|a\\.m\\.|p\\.m\\.)").matcher(x);
        if (m.find()) {
            int h = Integer.parseInt(m.group(1));
            int min = m.group(2) == null ? 0 : Integer.parseInt(m.group(2));
            String ap = m.group(3).toLowerCase(Locale.ROOT);
            if (ap.startsWith("p") && h < 12) h += 12;
            if (ap.startsWith("a") && h == 12) h = 0;
            return new TimeResult(true, h, min);
        }
        m = Pattern.compile("(?i)hora\\s*[:=]?\\s*(\\d{1,2})(?::(\\d{2}))?").matcher(x);
        if (m.find()) return new TimeResult(true, Integer.parseInt(m.group(1)),
                m.group(2) == null ? 0 : Integer.parseInt(m.group(2)));
        return new TimeResult(false, 0, 0);
    }

    static Price parsePrice(String x, Context c) {
        float usdCup = c.getSharedPreferences("detector", 0).getFloat("usdCup", 700f);
        float eurUsd = c.getSharedPreferences("detector", 0).getFloat("eurUsd", 1.17f);

        Matcher usd = Pattern.compile("(?i)([0-9]+(?:[.,][0-9]+)?)\\s*(?:usd|us\\$|dolares?)").matcher(x);
        if (usd.find()) return new Price(true, number(usd.group(1)));

        Matcher eur = Pattern.compile("(?i)([0-9]+(?:[.,][0-9]+)?)\\s*(?:eur|euros?|€)").matcher(x);
        if (eur.find()) return new Price(true, number(eur.group(1)) * eurUsd);

        Matcher cup = Pattern.compile("(?i)(?:precio\\s*[:=]?\\s*)?([0-9][0-9 .]*)\\s*(mil\\s*)?(?:cup)?\\b").matcher(x);
        if (cup.find()) {
            String raw = cup.group(1).trim();
            // Ignore tiny numbers likely to be unrelated text.
            double n = number(raw);
            if (cup.group(2) != null) n *= 1000;
            if (n >= 1000 && usdCup > 0) return new Price(true, n / usdCup);
        }
        return new Price(false, 0);
    }

    static double number(String s) {
        String t = s.replace(" ", "").replace(",", ".");
        return Double.parseDouble(t);
    }

    static class TimeResult { boolean known; int hour, minute; TimeResult(boolean k,int h,int m){known=k;hour=h;minute=m;} }
    static class Price { boolean known; double usd; Price(boolean k,double u){known=k;usd=u;} }
}
