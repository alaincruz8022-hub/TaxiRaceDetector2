# TaxiRaceDetector v0.2 — modo prueba

Detector de carreras de taxi para WhatsApp Business.

IMPORTANTE: esta versión SOLO LEE NOTIFICACIONES Y MUESTRA EL RESULTADO. NO ENVÍA "YO" Y NO SELECCIONA MENSAJES.

Reglas actuales:
- Aeropuerto/HAV/José Martí/Varadero.
- 1–4 pasajeros.
- Equipaje identificado y máximo 2 piezas; si no aparece el equipaje, queda descartada para revisión.
- Precio superior a 20 USD equivalentes.
- Hora 07:00–18:59.
- Rechaza confort/aire acondicionado.
- USD/CUP y EUR/USD son configurables desde la app.

## Compilar desde un móvil
Este proyecto incluye `.github/workflows/build-apk.yml` para construir el APK mediante GitHub Actions sin Android Studio local.

El workflow genera `app-debug.apk` como artefacto descargable.
